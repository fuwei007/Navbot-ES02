#ifndef ICM42688_H
#define ICM42688_H

#include "Arduino.h"
#include "Wire.h"    // I2C通信库
#include "SPI.h"     // SPI通信库

/* ICM42688传感器驱动类
 * 支持I2C和SPI两种通信方式
 * 提供加速度计、陀螺仪数据读取及校准功能
 */
class ICM42688
{
  public:
    // 陀螺仪量程枚举（单位：dps 度/秒）
    enum GyroFS : uint8_t {
      dps2000 = 0x00,   // ±2000dps
      dps1000 = 0x01,   // ±1000dps
      dps500 = 0x02,    // ±500dps
      dps250 = 0x03,    // ±250dps
      dps125 = 0x04,    // ±125dps
      dps62_5 = 0x05,   // ±62.5dps
      dps31_25 = 0x06,  // ±31.25dps
      dps15_625 = 0x07  // ±15.625dps
    };
    // 加速度计量程枚举（单位：g 重力加速度）
    enum AccelFS : uint8_t {
      gpm16 = 0x00,     // ±16g
      gpm8 = 0x01,      // ±8g
      gpm4 = 0x02,      // ±4g
      gpm2 = 0x03       // ±2g
    };

    // 输出数据速率枚举（单位：Hz）
    enum ODR : uint8_t {
      odr32k = 0x01,    // 32kHz 仅低噪声模式
      odr16k = 0x02,    // 16kHz 仅低噪声模式
      odr8k = 0x03,     // 8kHz 仅低噪声模式
      odr4k = 0x04,     // 4kHz 仅低噪声模式
      odr2k = 0x05,     // 2kHz 仅低噪声模式
      odr1k = 0x06,     // 1kHz 仅低噪声模式
      odr200 = 0x07,    // 200Hz
      odr100 = 0x08,    // 100Hz
      odr50 = 0x09,     // 50Hz
      odr25 = 0x0A,     // 25Hz
      odr12_5 = 0x0B,   // 12.5Hz
      odr6a25 = 0x0C,   // 6.25Hz 仅低功耗模式（仅加速度计）
      odr3a125 = 0x0D,  // 3.125Hz 仅低功耗模式（仅加速度计）
      odr1a5625 = 0x0E, // 1.5625Hz 仅低功耗模式（仅加速度计）
      odr500 = 0x0F,    // 500Hz
    };

    /* I2C通信构造函数
     * @param bus     使用的I2C总线对象
     * @param address 设备I2C地址（默认0x68/0x69）
     */
    ICM42688(TwoWire &bus, uint8_t address);

    /* SPI通信构造函数
     * @param bus      使用的SPI总线对象
     * @param csPin    片选引脚编号
     * @param SPI_HS_CLK 高速SPI时钟频率（默认8MHz）
     */
    ICM42688(SPIClass *bus, uint8_t csPin, uint32_t SPI_HS_CLK=8000000);

    /**
     * @brief      初始化传感器
     * @return     返回状态码，小于0表示错误
     */
    int begin();

    /**
     * @brief      设置加速度计量程
     * @param fssel 量程枚举值
     * @return     状态码，小于0表示错误
     */
    int setAccelFS(AccelFS fssel);

    /**
     * @brief      设置陀螺仪量程
     * @param fssel 量程枚举值
     * @return     状态码，小于0表示错误
     */
    int setGyroFS(GyroFS fssel);

    /**
     * @brief      设置加速度计输出数据速率
     * @param odr  数据速率枚举值
     * @return     状态码，小于0表示错误
     */
    int setAccelODR(ODR odr);

    /**
     * @brief      设置陀螺仪输出数据速率
     * @param odr  数据速率枚举值
     * @return     状态码，小于0表示错误
     */
    int setGyroODR(ODR odr);

    /**
     * @brief      启用/禁用传感器数字滤波器
     * @param gyroFilters true启用陀螺仪滤波器
     * @param accFilters  true启用加速度计滤波器
     * @return     状态码，小于0表示错误
     */
    int setFilters(bool gyroFilters, bool accFilters);

    /**
     * @brief      启用数据就绪中断（通过INT1引脚）
     * @return     状态码，小于0表示错误
     */
    int enableDataReadyInterrupt();

    /**
     * @brief      禁用数据就绪中断
     * @return     状态码，小于0表示错误
     */
    int disableDataReadyInterrupt();

    /**
     * @brief      读取传感器数据（必须调用此方法更新数据）
     * @return     状态码，小于0表示错误
     */
    int getAGT();

    // 获取X轴加速度（单位：g）
    float accX() const { return _acc[0]; }
    // 获取Y轴加速度（单位：g）
    float accY() const { return _acc[1]; }
    // 获取Z轴加速度（单位：g）
    float accZ() const { return _acc[2]; }

    // 获取X轴角速度（单位：dps）
    float gyrX() const { return _gyr[0]; }
    // 获取Y轴角速度（单位：dps）
    float gyrY() const { return _gyr[1]; }
    // 获取Z轴角速度（单位：dps）
    float gyrZ() const { return _gyr[2]; }

    // 获取芯片温度（单位：℃）
    float temp() const { return _t; }

    // 陀螺仪校准（传感器需保持静止）
    int calibrateGyro();
    // 获取X轴陀螺仪零偏
    float getGyroBiasX();
    // 获取Y轴陀螺仪零偏
    float getGyroBiasY();
    // 获取Z轴陀螺仪零偏
    float getGyroBiasZ();
    // 设置X轴陀螺仪零偏
    void setGyroBiasX(float bias);
    // 设置Y轴陀螺仪零偏
    void setGyroBiasY(float bias);
    // 设置Z轴陀螺仪零偏
    void setGyroBiasZ(float bias);
    
    // 加速度计校准（需要多方位旋转传感器）
    int calibrateAccel();
    // 获取X轴加速度计零偏（m/s²）
    float getAccelBiasX_mss();
    // 获取X轴比例因子
    float getAccelScaleFactorX();
    // 获取Y轴加速度计零偏（m/s²）
    float getAccelBiasY_mss();
    // 获取Y轴比例因子
    float getAccelScaleFactorY();
    // 获取Z轴加速度计零偏（m/s²）
    float getAccelBiasZ_mss();
    // 获取Z轴比例因子
    float getAccelScaleFactorZ();
    // 设置X轴校准参数
    void setAccelCalX(float bias,float scaleFactor);
    // 设置Y轴校准参数
    void setAccelCalY(float bias,float scaleFactor);
    // 设置Z轴校准参数
    void setAccelCalZ(float bias,float scaleFactor);
    
  protected:
    // I2C通信相关
    uint8_t _address = 0;       // 设备I2C地址
    TwoWire *_i2c = {};         // I2C总线指针
    static constexpr uint32_t I2C_CLK = 400000; // I2C时钟频率400kHz
    size_t _numBytes = 0;       // 接收字节数

    // SPI通信相关
    SPIClass *_spi = {};        // SPI总线指针
    uint8_t _csPin = 0;         // 片选引脚
    bool _useSPI = false;       // SPI使能标志
    bool _useSPIHS = false;     // 高速SPI模式标志
    static constexpr uint32_t SPI_LS_CLOCK = 1000000; // 低速SPI时钟1MHz
    uint32_t SPI_HS_CLOCK = 8000000; // 高速SPI时钟8MHz

    uint8_t _buffer[15] = {};   // 原始数据缓冲区

    // 处理后的传感器数据
    float _t = 0.0f;            // 温度值（℃）
    float _acc[3] = {};         // 三轴加速度数据（g）
    float _gyr[3] = {};         // 三轴角速度数据（dps）

    // 量程换算系数
    float _accelScale = 0.0f;   // 加速度计LSB/g系数
    float _gyroScale = 0.0f;    // 陀螺仪LSB/dps系数

    // 当前量程设置
    AccelFS _accelFS;           // 加速度计量程配置
    GyroFS _gyroFS;             // 陀螺仪量程配置

    // 加速度计校准参数
    float _accBD[3] = {};       // 原始零偏数据
    float _accB[3] = {};        // 零偏校准值（m/s²）
    float _accS[3] = {1.0f, 1.0f, 1.0f}; // 比例因子
    float _accMax[3] = {};      // 校准过程最大值记录
    float _accMin[3] = {};      // 校准过程最小值记录

    // 陀螺仪校准参数
    float _gyroBD[3] = {};      // 原始零偏数据
    float _gyrB[3] = {};        // 零偏校准值（dps）

    // 常量定义
    static constexpr uint8_t WHO_AM_I = 0x47; // 设备ID寄存器期望值
    static constexpr int NUM_CALIB_SAMPLES = 1000; // 校准采样次数

    // 温度转换常数（来自数据手册4.13节）
    static constexpr float TEMP_DATA_REG_SCALE = 132.48f; // 缩放系数
    static constexpr float TEMP_OFFSET = 25.0f;           // 偏移量

    uint8_t _bank = 0;          // 当前寄存器Bank

    // FIFO相关寄存器位定义
    const uint8_t FIFO_EN = 0x23;          // FIFO使能寄存器地址
    const uint8_t FIFO_TEMP_EN = 0x04;     // 温度FIFO使能位
    const uint8_t FIFO_GYRO = 0x02;        // 陀螺仪FIFO使能位
    const uint8_t FIFO_ACCEL = 0x01;       // 加速度计FIFO使能位
    
    // const uint8_t FIFO_COUNT = 0x2E;
    // const uint8_t FIFO_DATA = 0x30;

    // BANK 1
    // const uint8_t GYRO_CONFIG_STATIC2 = 0x0B;
    // Bank1寄存器位定义
    const uint8_t GYRO_NF_ENABLE = 0x00;   // 陀螺仪噪声滤波器使能
    const uint8_t GYRO_NF_DISABLE = 0x01;  // 陀螺仪噪声滤波器禁用
    const uint8_t GYRO_AAF_ENABLE = 0x00;  // 陀螺仪抗混叠滤波器使能
    const uint8_t GYRO_AAF_DISABLE = 0x02; // 陀螺仪抗混叠滤波器禁用

    // Bank2寄存器位定义
    const uint8_t ACCEL_AAF_ENABLE = 0x00;  // 加速度计抗混叠滤波器使能
    const uint8_t ACCEL_AAF_DISABLE = 0x01; // 加速度计抗混叠滤波器禁用

    // 私有方法
    int writeRegister(uint8_t subAddress, uint8_t data); // 寄存器写入
    int readRegisters(uint8_t subAddress, uint8_t count, uint8_t* dest); // 寄存器读取
    int setBank(uint8_t bank); // 切换寄存器Bank

    /**
     * @brief      执行软件复位
     */
    void reset();
    /**
     * @brief      读取WHO_AM_I寄存器
     * @return     寄存器值
     */
    uint8_t whoAmI();
};


/* FIFO功能扩展类
 * 继承基础传感器类，增加FIFO操作功能
 */
class ICM42688_FIFO: public ICM42688 {
  public:
    using ICM42688::ICM42688; // 继承基类构造函数
    
    /**
     * @brief      启用FIFO功能
     * @param accel 是否启用加速度计FIFO
     * @param gyro  是否启用陀螺仪FIFO
     * @param temp  是否启用温度FIFO
     * @return     状态码，小于0表示错误
     */
    int enableFifo(bool accel,bool gyro,bool temp);
    
    /**
     * @brief      读取FIFO数据
     * @return     状态码，小于0表示错误
     */
    int readFifo();
    
    // 以下方法获取FIFO数据并存入指定数组
    void getFifoAccelX_mss(size_t *size,float* data);
    void getFifoAccelY_mss(size_t *size,float* data);
    void getFifoAccelZ_mss(size_t *size,float* data);
    void getFifoGyroX(size_t *size,float* data);
    void getFifoGyroY(size_t *size,float* data);
    void getFifoGyroZ(size_t *size,float* data);
    void getFifoTemperature_C(size_t *size,float* data);
    
  protected:
    // FIFO状态标志
    bool _enFifoAccel = false;  // 加速度计FIFO使能
    bool _enFifoGyro = false;   // 陀螺仪FIFO使能
    bool _enFifoTemp = false;   // 温度FIFO使能
    
    // FIFO存储结构
    size_t _fifoSize = 0;       // FIFO总数据量
    size_t _fifoFrameSize = 0;  // 单帧数据大小
    
    // FIFO数据缓冲区（按数据手册最大FIFO大小设置）
    float _axFifo[85] = {};     // X轴加速度FIFO
    float _ayFifo[85] = {};     // Y轴加速度FIFO 
    float _azFifo[85] = {};     // Z轴加速度FIFO
    size_t _aSize = 0;          // 加速度计数据计数
    
    float _gxFifo[85] = {};     // X轴陀螺仪FIFO
    float _gyFifo[85] = {};     // Y轴陀螺仪FIFO
    float _gzFifo[85] = {};     // Z轴陀螺仪FIFO
    size_t _gSize = 0;          // 陀螺仪数据计数
    
    float _tFifo[256] = {};     // 温度FIFO（更大存储空间）
    size_t _tSize = 0;          // 温度数据计数
};

#endif // ICM42688_H
